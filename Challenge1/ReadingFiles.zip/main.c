#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedList.h"




int printYoungest(struct LinkedList *l){
  if(l->size== 0){
    printf("The list has no elements");
  }
  else if(l->size==1){
    int index = 0 ; 
    struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
    indexNode  = l->firstNode;
    printf("The youngest person is %s with an age of %d",indexNode->name,indexNode->age);
    }
    
   else{
      
      struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
      indexNode  = l->firstNode;
      struct Node *youngest = (struct Node*) malloc(sizeof(struct Node));
      youngest->age = indexNode->age; 
      while(indexNode->nextNode != NULL){
          indexNode = indexNode->nextNode; 
          if(indexNode->age < youngest->age){
            youngest->age = indexNode->age;
            youngest->name = indexNode->name;
          } 
      }
      printf("The youngest age is %s with an age of %d",youngest->name,youngest->age);
   }
  return 0;
}

int printOldest(struct LinkedList *l){
  if(l->size== 0){
    printf("The list has no elements");
  }
  else if(l->size==1){
    int index = 0 ; 
    struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
    indexNode  = l->firstNode;
    printf("The youngest person is %s with an age of %d",indexNode->name,indexNode->age);
    }
    
   else{
      
      struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
      indexNode  = l->firstNode;
      struct Node *oldest = (struct Node*) malloc(sizeof(struct Node));
      oldest->age = indexNode->age; 
      while(indexNode->nextNode != NULL){
          indexNode = indexNode->nextNode; 
          if(indexNode->age > oldest->age){
            oldest->age = indexNode->age;
            oldest->name = indexNode->name;
          } 
      }
      printf("The oldest age is %s with an age of %d",oldest->name,oldest->age);
   }
  return 0; 
}

int averageAge(struct LinkedList *l){
  if(l->size== 0){
    printf("The list has no elements");
  }
  else if(l->size==1){
    int index = 0 ; 
    struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
    indexNode  = l->firstNode;
    printf("The average age is: %d", indexNode->age);
  }else{
      int index = 0 ; 
      struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
      indexNode  = l->firstNode;
      int total = 0;
      total = total + indexNode->age;
      while(indexNode->nextNode != NULL){
          index++;
          indexNode = indexNode->nextNode; 
          total = total + indexNode->age;
      }
      double average = total/l->size;
      printf("The average age is: %.3lf ",average);
  }
  return 0;
}

int printStartingWith(struct LinkedList *l, char c){
  if(l->size== 0){
    printf("The list has no elements");
  }
  else if(l->size==1){
    int index = 0 ; 
    struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
    indexNode = l->firstNode;
    if(indexNode->name[0] == c){
      printf("%s",indexNode->name);
    }
  }else{
      struct Node *indexNode = (struct Node*) malloc(sizeof(struct Node));
      indexNode  = l->firstNode;
      int total = 0;
      while(indexNode->nextNode != NULL){
          if(indexNode->name[0] == c){
            printf("%s\n",indexNode->name);
          }
          indexNode = indexNode->nextNode;  
      }
  }
  return 0;
}
int main(void) {
   struct LinkedList *linkedList = (struct LinkedList*) calloc(1,sizeof(struct LinkedList));
  loadList(linkedList);
  
  int option;
  printf("What do you want to do? \n 1)Print the linked list \n 2)Print the oldest person \n 3)Print the youngest person \n 4)Print the average of ages \n 5)Print all names that start with a given letter \n 6)Quit \n");
  scanf("%d", &option);

    switch(option) {
      case 1:
        printf("Printing the loaded data from the CSV...\n");
       printLinkedList(linkedList);
        break;
      case 2:
        printf("Printing the oldest person from the CSV ...\n");
        printOldest(linkedList);
        break;
      case 3:
       printf("Printing the youngest person from the CSV ...\n");
        printYoungest(linkedList);
        break;
      case 4:
        printf("Printing the average age from the CSV ..\n");
       averageAge(linkedList);
      break;
     case 5:
       printStartingWith(linkedList, 'A');
      break;
     case 6:
      exit(1);
       break;
     default:
      printf("Type a valid option! \n");
       break;
  }

  return 0;
}
